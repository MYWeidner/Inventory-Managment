#include <iostream>
#include "../code/Treap.h"

using namespace std;

int main(){

    return 0;
}